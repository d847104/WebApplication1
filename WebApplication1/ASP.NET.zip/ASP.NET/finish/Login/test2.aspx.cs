﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class test2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                user.Text = "請輸入帳號";
                passwd.Text = "請輸入密碼";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (user.Text == "lccnet")
            {
                user.Text = "";
                if (passwd.Text == "123456")
                {
                    Response.Redirect("http://www.yahoo.com.tw");
                }
                else
                {
                    passwdLabel.Text="密碼輸入錯誤";
                }
            }
            else
            {
                userLabel.Text="帳號輸入錯誤";
            }            
        }
    }
}